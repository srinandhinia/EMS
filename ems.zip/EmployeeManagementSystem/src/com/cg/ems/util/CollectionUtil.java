package com.cg.ems.util;

import java.time.LocalDate;
import java.time.Month;
import java.util.HashSet;

import com.cg.ems.dto.Employee;

public class CollectionUtil {


	private static HashSet<Employee> empSet = new HashSet<Employee>();
	
	static
	{
		empSet.add(new Employee(112081,"Vaishali S",5000.0F,LocalDate.of(2014, Month.MARCH, 04)));
		empSet.add(new Employee(160662,"Dinesh Nandi",88000.0F,LocalDate.of(2018, Month.SEPTEMBER, 26)));
		empSet.add(new Employee(160601,"Abhimanu",89000.0F,LocalDate.of(2018, Month.SEPTEMBER, 14)));
		empSet.add(new Employee(160601,"Tandon",12000.0F,LocalDate.of(2014, Month.DECEMBER, 15)));
		empSet.add(new Employee(160708,"Sai Kiran",26000.0F,LocalDate.of(2014, Month.JANUARY, 8)));
	}
	
	public static void addEmp(Employee emp)
	{
		empSet.add(emp);
		
	}
	
	public static HashSet<Employee> getAllEmp()
	{
		return empSet;
	}

	
	
	
	
}
