package com.cg.ems.dao;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.cg.ems.dto.Employee;
import com.cg.ems.exception.EmployeeException;
import com.cg.ems.util.CollectionUtil;

public class EmpDAOImpl implements EmpDAO{

	//CollectionUtil colUtil=null;
	@Override
	public int addEmployee(Employee ee) throws EmployeeException {
		// TODO Auto-generated method stub
		CollectionUtil.addEmp(ee);
		return ee.getEmpId();
	}

	@Override
	public HashSet<Employee> fetchAllEmp() {
		// TODO Auto-generated method stub
		return CollectionUtil.getAllEmp();
	}

	@Override
	public Employee getEmpById(int empId) {
		HashSet<Employee> emp= CollectionUtil.getAllEmp();
		Iterator<Employee> it=emp.iterator();
		Employee ee=null;
		while(it.hasNext())
		{
			Employee e=it.next();
			if(e.getEmpId()==empId)
				
			{
				ee=e;
			}
		}
		return ee;
	}

	@Override
	public HashSet<Employee> searchEmpByName(String name) {
		// TODO Auto-generated method stub
		HashSet<Employee> emp= CollectionUtil.getAllEmp();
		Iterator<Employee> it=emp.iterator();
		HashSet <Employee> eee=new HashSet<Employee>();
		
		while(it.hasNext())
		{
			Employee e=it.next();
			if(e.getEmpName().equals(name))
				
			{
				eee.add(e);
			}
		}
		return eee;
		
	}

	@Override
	public int deleteEmp(int empId) {
		// TODO Auto-generated method stub
		HashSet<Employee> list= CollectionUtil.getAllEmp();
		Iterator<Employee> it=list.iterator();
		while(it.hasNext())
		{
			Employee e= it.next();
			if(e.getEmpId()==empId)
			{
				list.remove(e);
				return 1;
			}
		}
		return 0;
	}

	@Override
	public Employee updateEmp(int eid, String newName, float newSal) {
		// TODO Auto-generated method stub
		HashSet<Employee> emp= CollectionUtil.getAllEmp();
		Iterator<Employee> it=emp.iterator();
		Employee e=null;
		while(it.hasNext())
		{
			Employee ee=it.next();
			if(ee.getEmpId()==eid)
			{
				e=ee;
				e.setEmpName(newName);
				e.setEmpSal(newSal);
			}
		}
		return e;
	}

}
